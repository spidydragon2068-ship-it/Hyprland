#!/bin/bash

rofi -show drun

